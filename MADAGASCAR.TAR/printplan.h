
  /*   2010 (C) Jussi Rintanen   */

void fprintplan(FILE *,satinstance);
void printplanT(satinstance);	/* Print action and state variables. */
void printplanV(satinstance);	/* Print state variables only. */
void printTlit(satinstance,int);
void printUvar(int);
